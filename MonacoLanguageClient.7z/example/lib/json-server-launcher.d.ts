import * as rpc from "vscode-ws-jsonrpc";
export declare function launch(socket: rpc.IWebSocket): void;
//# sourceMappingURL=json-server-launcher.d.ts.map