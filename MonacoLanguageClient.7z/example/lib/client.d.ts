import "monaco-languages/release/esm/csharp/csharp.contribution";
//# sourceMappingURL=client.d.ts.map