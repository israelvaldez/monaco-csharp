/* --------------------------------------------------------------------------------------------
 * Copyright (c) 2018 TypeFox GmbH (http://www.typefox.io). All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 * ------------------------------------------------------------------------------------------ */
import { listen, MessageConnection } from "vscode-ws-jsonrpc";
import {
  MonacoLanguageClient,
  CloseAction,
  ErrorAction,
  MonacoServices,
  createConnection
} from "monaco-languageclient";
import normalizeUrl = require("normalize-url");
//import './csharp/csharp.contribution';
import "monaco-languages/release/esm/csharp/csharp.contribution";
const ReconnectingWebSocket = require("reconnecting-websocket");

// create Monaco editor
const value = `
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Erp;
using Erp.Contracts;
using Ice.Assemblies;

    static void test()
    {
        var context = new ErpContext();
        var partRecord = new Erp.Tables.Part();
        using(var service = ServiceRenderer.GetService<PartSvcContract>()){
        }
    }

`;

const editor = monaco.editor.create(document.getElementById("container")!, {
  model: monaco.editor.createModel(
    value,
    "csharp",
    monaco.Uri.parse("file://C:/Temp/Omni/ConsoleApp1/ConsoleApp1/Program.cs")
  ),
  glyphMargin: true,
  lightbulb: {
    enabled: true
  },
  selectOnLineNumbers: true,
  find: {
    autoFindInSelection: true,
    seedSearchStringFromSelection: true
  },
  hover: {
    enabled: true
  },
  codeLens: true,
  parameterHints: true,
  autoClosingBrackets: true,
  autoIndent: true,
  showUnused: true
});

/*
editor.onDidChangeModelContent(e => {
  console.log("---");
  e.changes.forEach(change => {
    if (change.range.startLineNumber <= 9) {
      editor.trigger("", "undo", "");
    }
  });
  console.log(e.changes.length);
});
*/

// install Monaco language client services
MonacoServices.install(editor, {
  rootUri: "file://C:/Temp/Omni/ConsoleApp1/ConsoleApp1.sln"
});

// create the web socket
const url = createUrl("/sampleServer");
const webSocket = createWebSocket(url);
// listen when the web socket is opened
listen({
  webSocket,
  onConnection: connection => {
    // create and start the language client
    const languageClient = createLanguageClient(connection);
    const disposable = languageClient.start();
    connection.onClose(() => disposable.dispose());
  }
});

function createLanguageClient(
  connection: MessageConnection
): MonacoLanguageClient {
  return new MonacoLanguageClient({
    name: "Sample Language Client",
    clientOptions: {
      // use a language id as a document selector
      documentSelector: [
        { language: "csharp" },
        { language: "csharp", pattern: "**∕Program.cs" }
      ],
      // disable the default error handler
      errorHandler: {
        error: () => ErrorAction.Continue,
        closed: () => CloseAction.DoNotRestart
      }
    },
    // create a language client connection from the JSON RPC connection on demand
    connectionProvider: {
      get: (errorHandler, closeHandler) => {
        return Promise.resolve(
          createConnection(connection, errorHandler, closeHandler)
        );
      }
    }
  });
}

function createUrl(path: string): string {
  const protocol = location.protocol === "https:" ? "wss" : "ws";
  return normalizeUrl(
    `${protocol}://${location.host}${location.pathname}${path}`
  );
}

function createWebSocket(url: string): WebSocket {
  const socketOptions = {
    maxReconnectionDelay: 10000,
    minReconnectionDelay: 1000,
    reconnectionDelayGrowFactor: 1.3,
    connectionTimeout: 10000,
    maxRetries: Infinity,
    debug: false
  };
  return new ReconnectingWebSocket(url, undefined, socketOptions);
}
