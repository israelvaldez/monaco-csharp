/// <reference path="../node_modules/vscode/vscode.d.ts" />
declare const _default: typeof import("vscode");
export = _default;
//# sourceMappingURL=vscode-compatibility.d.ts.map