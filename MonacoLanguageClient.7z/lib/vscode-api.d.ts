import * as vscode from "vscode";
import { Services } from "./services";
export declare function createVSCodeApi(servicesProvider: Services.Provider): typeof vscode;
//# sourceMappingURL=vscode-api.d.ts.map