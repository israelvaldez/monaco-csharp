export {};
//# sourceMappingURL=register-vscode.d.ts.map