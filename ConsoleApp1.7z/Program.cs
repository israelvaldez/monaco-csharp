﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Erp;
using Erp.Contracts;
using Ice.Assemblies;

static void test()
{
    var context = new ErpContext();
    var partRecord = new Erp.Tables.Part();
    using (var service = ServiceRenderer.GetService<PartSvcContract>())
    {
        
    }
}